**********************************************************************
OpenI 2.0 Alpha 
**********************************************************************

The openi-2.0 alpha release of the OpenI codebase is a J2EE web application
to build and publish interactive reports from OLAP databases, RDBMS, 
and data mining applications. For installation and user guide, see 
docs/INSTALL.html and docs/userguide.html.


**********************************************************************
Documentation and Help
**********************************************************************

Documentation index: docs/index.html
Installation: docs/INSTALL.html
User Guide: docs/userguide.html
Change Log: docs/changelog.html
Support Forum: http://sourceforge.net/forum/?group_id=142873


**********************************************************************
Source Code
**********************************************************************

Available from https://openi.svn.sourceforge.net/svnroot/openi/openi_2_0/. 
See docs/INSTALL.html for build instructions.


**********************************************************************
Licenses
**********************************************************************

OpenI is licensed under the OpenI Public License 1.0, which consists
of Mozilla Public License 1.1 with some modifications. The license 
texts for OpenI and the thirdparty components it uses may be found in 
the "docs/licenses" directory of the distribution. 

For more information, see: 

docs/LICENSE.txt - license agreement for OpenI
docs/3rd-party-licenses.txt - list of all 3rd party libraries, and 
					their respective licenses
docs/licenses - folder with full license text for all individual  
			licenses for 3rd party libraries


**********************************************************************
About OpenI.org
**********************************************************************

OpenI is an open source project that started in 2005 with the goal to
provide a simple, intuitive Business Intelligence software product.  
The project started with providing reporting and analytics 
capabilities off OLAP datta using interactive tables, charts, and 
dashboards, and quickly extended into providing support for RDBMS 
reporting and data mining. 

OpenI's focus is to enhance the usability of Business Intellignce 
software by simplifying the interface as well as widening the access 
to different types of data. Future roadmap includes providing more 
simple tools that make it easier to conduct exploratory analysis, 
report and share analysis results, and also connect to external 
systems that can take actions based on the analyses conducted within 
OpenI.


Copyright (c) 2005 - 2008, OpenI.org.
