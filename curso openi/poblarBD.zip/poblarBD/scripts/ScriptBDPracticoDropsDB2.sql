// Este Script elimina las tablas de la BD practico
DROP TABLE /nombre/.FacturaDetalle;
DROP TABLE /nombre/.FacturaCabecera;
DROP TABLE /nombre/.Clientes;
DROP TABLE /nombre/.Productos;
DROP TABLE /nombre/.Proveedores;
DROP TABLE /nombre/.Vendedores;
DROP TABLE /nombre/.Rubros;
DROP TABLE /nombre/.Zonas;