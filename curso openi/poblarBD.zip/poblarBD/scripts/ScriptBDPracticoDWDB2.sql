
CREATE TABLE /nombre/.DW_ClientesLookup (
  idCliente INTEGER NOT NULL,
  cliente VARCHAR(45) NOT NULL,
  zona VARCHAR(45) NOT NULL,
  cuentaHabilitada INTEGER NOT NULL,
  PRIMARY KEY(idCliente)
);

CREATE TABLE /nombre/.DW_VendedoresLookup(
  idVendedor integer NOT NULL,
  Vendedor varchar(45) NOT NULL,
  Comision float NOT NULL,
  PRIMARY KEY  (idVendedor)
);

CREATE TABLE /nombre/.DW_ProductosLookup (
  idProducto integer NOT NULL,
  Producto varchar(45) NOT NULL,
  Rubro varchar(45) NOT NULL,
  Proveedor varchar(45) NOT NULL,
  PRIMARY KEY  (idProducto)
);

CREATE TABLE  /nombre/.DW_TiemposLookup (
  fecha date NOT NULL,
  anio integer NOT NULL,
  semestre integer NOT NULL,
  trimestre integer NOT NULL,
  bimestre integer NOT NULL,
  mesNumero integer NOT NULL,
  mesLetra varchar(15) NOT NULL,
  semanaMes integer NOT NULL,
  diaSemanaNumero integer NOT NULL,
  diaSemanaLetra varchar(15) NOT NULL,
  estacion varchar(10) NOT NULL,
  PRIMARY KEY  (fecha)
);

CREATE TABLE /nombre/.DW_VentasFact (
  fecha date NOT NULL,
  idCliente INTEGER NOT NULL,
  idVendedor integer NOT NULL,
  idProducto integer NOT NULL,
  cantidad float NOT NULL,
  importe float NOT NULL,
  PRIMARY KEY  (fecha,idCliente,idVendedor,idProducto)
);

