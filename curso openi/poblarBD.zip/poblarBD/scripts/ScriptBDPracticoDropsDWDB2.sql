// Este Script elimina las tablas del DW de la BD practico

DROP TABLE DW_ClientesLookup;
DROP TABLE DW_VendedoresLookup;
DROP TABLE DW_ProductosLookup;
DROP TABLE DW_TiemposLookup;
DROP TABLE DW_VentasFact;