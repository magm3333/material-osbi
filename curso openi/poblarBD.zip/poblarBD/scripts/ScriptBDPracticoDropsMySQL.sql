// Este Script elimina las tablas de la BD practico
DROP TABLE FacturaDetalle;
DROP TABLE FacturaCabecera;
DROP TABLE Clientes;
DROP TABLE Productos;
DROP TABLE Proveedores;
DROP TABLE Vendedores;
DROP TABLE Rubros;
DROP TABLE Zonas;