// Poblar DE DB2

DELETE FROM DW_ClientesLookup;
DELETE FROM DW_VendedoresLookup;
DELETE FROM DW_ProductosLookup;
DELETE FROM DW_ventasFact;


INSERT INTO DW_ClientesLookup
SELECT
  c.idCliente,
  c.Cliente,
  z.Zona,
  c.cuentaHabilitada
FROM
  Clientes c INNER JOIN Zonas z
    ON c.idZona=z.idZona;

INSERT INTO DW_VendedoresLookup
SELECT
  idVendedor,
  vendedor,
  comision
FROM
  Vendedores;

INSERT INTO DW_ProductosLookup
SELECT
  p.idProducto,
  p.Producto,
  r.Rubro,
  pr.Proveedor
FROM
  Productos p INNER JOIN Rubros r
    ON p.idRubro=r.idRubro
  INNER JOIN Proveedores pr
    ON p.idProveedor=pr.idProveedor;

INSERT INTO DW_ventasFact
SELECT
  c.fecha,
  c.idCliente,
  c.idVendedor,
  d.idProducto,
  sum(d.cantidad) as cantidad,
  sum(d.cantidad*p.precio) as importe
FROM
  facturaCabecera c INNER JOIN facturaDetalle d
    ON c.idFactura=d.idFactura
  INNER JOIN Productos p
    ON d.idProducto=p.idProducto
WHERE
  anulada=0
GROUP BY
  c.fecha, c.idCliente, c.idVendedor, d.idProducto;



