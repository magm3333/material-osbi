
CREATE TABLE `DW_ClientesLookup` (
  `idCliente` INTEGER UNSIGNED NOT NULL,
  `cliente` VARCHAR(45) NOT NULL DEFAULT '',
  `zona` VARCHAR(45) NOT NULL DEFAULT '',
  `cuentaHabilitada` INTEGER UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY(`idCliente`)
);

CREATE TABLE `DW_VendedoresLookup`(
  `idVendedor` integer unsigned NOT NULL,
  `Vendedor` varchar(45) NOT NULL,
  `Comision` float NOT NULL,
  PRIMARY KEY  (`idVendedor`)
);

CREATE TABLE `DW_ProductosLookup` (
  `idProducto` integer unsigned NOT NULL,
  `Producto` varchar(45) NOT NULL,
  `Rubro` varchar(45) NOT NULL,
  `Proveedor` varchar(45) NOT NULL,
  PRIMARY KEY  (`idProducto`)
);

CREATE TABLE  `DW_TiemposLookup` (
  `fecha` date NOT NULL,
  `anio` integer NOT NULL,
  `semestre` integer NOT NULL,
  `trimestre` integer NOT NULL,
  `bimestre` integer NOT NULL,
  `mesNumero` integer NOT NULL,
  `mesLetra` varchar(15) NOT NULL,
  `semanaMes` integer NOT NULL,
  `diaSemanaNumero` integer NOT NULL,
  `diaSemanaLetra` varchar(15) NOT NULL,
  `estacion` varchar(10) NOT NULL,
  PRIMARY KEY  (`fecha`)
);

CREATE TABLE `DW_VentasFact` (
  `fecha` date NOT NULL,
  `idCliente` INTEGER UNSIGNED NOT NULL,
  `idVendedor` integer unsigned NOT NULL,
  `idProducto` integer unsigned NOT NULL,
  `cantidad` float NOT NULL,
  `importe` float NOT NULL,
  PRIMARY KEY  (`fecha`,`idCliente`,`idVendedor`,`idProducto`)
);

