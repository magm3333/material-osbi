/*
Creado: 22/Nov/2010 (Impolementaci�n completa)
Update: 03/Nov/2011 (Soporte CDA + jQuery UI Styling + BugFix PageLength + Problemas de concurrencia de hilos para m�ltiples instancias)
Desarrollado por Mariano Garc�a Matt�o para grupo eGlu/OpenBits 
Se otorga permiso para copiar, distribuir y/o modificar este
documento bajo los t�rminos de la Licencia de Documentaci�n Libre de
GNU, Versi�n 1.3 o cualquier otra versi�n posterior publicada por la Free
Software Foundation. 

Developed by Mariano Garc�a Matt�o (magm3333@gmail,com)
Powered by grupo eGlu/OpenBits 

http://www.eglubi.com.ar
http://www.openbits.com.ar

*/

// TODO
// i18n labels
// funci�n para retornar seleccionados en id y descripci�n

var FilterTwoListBaseComponent = BaseComponent.extend({},{
	path : Dashboards.getQueryParameter("path"),
	solution : Dashboards.getQueryParameter("solution"),
	htmlObject : Dashboards.getQueryParameter("htmlObject"),
	action : Dashboards.getQueryParameter("action"),
	pageLength: Dashboards.getQueryParameter("pageLength"),
	keepDestSorted: Dashboards.getQueryParameter("keepDestSorted"),
	sortDestByKey : Dashboards.getQueryParameter("sortDestByKey"),
	initParameterString: Dashboards.getQueryParameter("initParameterString"),
	endParameterString: Dashboards.getQueryParameter("endParameterString"),
	joinParameterString: Dashboards.getQueryParameter("joinParameterString"),
	fillParameterWithId: Dashboards.getQueryParameter("fillParameterWithId"),
	minLengthForSearchAll:  Dashboards.getQueryParameter("minLengthForSearchAll")
});

var FilterTwoListComponent = FilterTwoListBaseComponent.extend({
	page: 1,
	pages: 1,
	dataLength: 0,
	fromIdx: 0,
	toIdx: 0,
	setupPages: function() {
		this.page=0;
		this.pages=0;
		this.fromIdx=0;
		this.toIdx=0;
		if (this.dataLength==0)  {
			return;
		}
		if (this.dataLength<=this.pageLength) {
			this.page=1;
			this.pages=1;
		} else {
			this.page=1;
			this.pages=((this.dataLength-(this.dataLength%this.pageLength))/this.pageLength);
			if (this.pages*this.pageLength<this.dataLength)
				this.pages++;
		}
		this.setupPageRange();
	},
	setupPageRange : function() {
		this.fromIdx=((this.page-1)*this.pageLength);
		this.toIdx=this.fromIdx+this.pageLength;
		if (this.toIdx>this.dataLength)
			this.toIdx=this.dataLength;
	},



	refreshPageButtons : function() {
		var myself = this;

		if (myself.page>1) {
			$('#'+myself.name+"_btnGoFirst").removeAttr('disabled');			
			$('#'+myself.name+"_btnGoPrev").removeAttr('disabled');
		} else {
			$('#'+myself.name+"_btnGoFirst").attr('disabled','disabled');			
			$('#'+myself.name+"_btnGoPrev").attr('disabled','disabled');
		}
		if (myself.page<myself.pages) {
			$('#'+myself.name+"_btnGoNext").removeAttr('disabled');			
			$('#'+myself.name+"_btnGoLast").removeAttr('disabled');
		} else {
			$('#'+myself.name+"_btnGoNext").attr('disabled','disabled');			
			$('#'+myself.name+"_btnGoLast").attr('disabled','disabled');
		}			
		$('#'+myself.name+"_pageSel").html('(Pag: <input id="'+myself.name+"_txtPage"+'" type="text" size="4" maxlength="4" value="'+myself.page+'"/>');		
		$('#'+myself.name+"_pageInfo").html('/'+myself.pages+') Items: '+myself.dataLength+' (Actual: '+(myself.fromIdx+1)+'/'+(myself.toIdx)+')');
		$('#'+myself.name+"_txtPage").keydown(function(event) {
			if (event.keyCode == 13) {
				myself.inputPage();
				return;
			}
        		if ( event.keyCode == 46 || event.keyCode == 8 || event.keyCode == 9 ) {
	        	} else {
                		if (event.keyCode < 48 || event.keyCode > 57 ) {
                        	event.preventDefault(); 
				}       
        		}
    		});
		$('#'+myself.name+"_txtPage").blur(function() {
			myself.inputPage();
    	});
	},




	inputPage: function() {
		var v=$('#'+this.name+"_txtPage").val();
		if (v<1 || v>this.pages) {
			$('#'+this.name+"_txtPage").val(this.page);
			return;
		}
		if (v!=this.page) {
			this.page=v;
			this.refreshPage();
		}
	},
	refreshPage : function() {
		Dashboards.incrementRunningCalls();
		this.setupPageRange();
		this.refreshSource();
		this.refreshPageButtons();
		Dashboards.decrementRunningCalls();	
	},
	goNextPage : function() {
		if(this.page<this.pages) {
			this.page++;
			this.refreshPage();
		}
	},
	goPrevPage : function() {
		if(this.page>1) {
			this.page--;
			this.refreshPage();
		}
	},
	goLastPage : function() {
		if(this.page!=this.pages) {
			this.page=this.pages;
			this.refreshPage();
		}
	},
	goFirstPage : function() {
		if(this.page!=1) {
			this.page=1;
			this.refreshPage();
		}
	},
	refreshSource : function() {
		Dashboards.incrementRunningCalls();		
		var firstVal;
		var selectHTML='';
		var vid = this.valueAsId==false?false:true;
		var myArray=this.dataArray;

		var lstDestItems=$("#"+this.name+"_lstDest option");
		var cant=0;
		for(var i= this.fromIdx, len  = this.toIdx; i < len; i++){
			if(myArray[i]!= null && myArray[i].length>0) {
				var ivid = vid || myArray[i][0] == null;
				var value, label;
				if (myArray[i].length > 1) {
					value = myArray[i][ivid?1:0];
					label = myArray[i][1];
				} else {
					value = myArray[i][0];
					label = myArray[i][0];
				}
				if (i == 0) {
					firstVal = value;
				}
				if (label.toLowerCase().indexOf(this.txtSearch.toLowerCase()) != -1) { // match with search text
					var ins=true;
					$.each(lstDestItems, function(key, e){
						if (value==e.value) {
							ins=false;
							return false;
						}
					});
					if (ins) {
						selectHTML += "<option value = '" + value + "' >" + label + "</option>";
						cant++;
					}
				}
			}
		}
		$('#'+this.name+"_lstSource").children().remove();
		$('#'+this.name+"_lstSource").append(selectHTML);
		$('#'+this.name+"_visiblesInfo").html(" [visible: "+cant+"]");
		Dashboards.decrementRunningCalls();
	},



update : function() {
		Dashboards.incrementRunningCalls();
		var myself = this;
		
		myself.dataArray = myself.getValuesArray();
		myself.dataArrayFull = $.merge([], myself.dataArray);
		myself.dataLength=myself.dataArray.length;

		var ph=$("#"+myself.htmlObject);
		var selectHTML = "<select style='font-family: courier; font-size: 10pt; width:100%; height:100%;' id='"+myself.name+"_lstSource'";
		if (myself.size != undefined){
			selectHTML += " size='" + myself.size + "' multiple></select>";
		}
		
		var selectDestHTML = "<select style='font-family: courier; font-size: 10pt; width:100%; height:100%;' id='"+myself.name+"_lstDest'";
		if (myself.size != undefined){
			selectDestHTML += " size='" + myself.size + "' multiple></select>";
		}		
		html= "<table border='0'>";
		html+=" <tr>";
		html+="  <td colspan='3' style='padding: 3px' class='fg-toolbar ui-toolbar ui-widget-header ui-corner-tl ui-corner-tr'>";
		html+="    <b>Global Filter:</b> <input type='text' id='"+myself.name+"_txtSearchAll' size='20'/>";
		html+="    <input class='ui-button' type='button' id='"+myself.name+"_btnSearchAll' value='Search' disabled='disabled'/> ";
		html+="    <input class='ui-button' type='button' id='"+myself.name+"_btnSearchAllClear' value='Clear Filter' disabled='disabled'/><hr/>";
		html+="    Page Filter: <input type='text' id='"+myself.name+"_txtSearch' size='20'/>";
		html+="  </td>";
		html+=" <tr class='ui-widget-content'>";
		html+="  <td style='width:45%'><div>"+selectHTML+"</div></td>";
		html+="  <td style='style='width:10%''><div style='text-align:center'>";
		html+="   <input type='button' class='"+myself.name+"_btnF2D ui-button' id='"+myself.name+"_btnSourceToDest' value='->'/><br/>";
		html+="   <input type='button' class='"+myself.name+"_btnF2D ui-button' id='"+myself.name+"_btnSourceToDestAll' value='>>'/><br/><br/>";
		html+="   <input type='button' class='"+myself.name+"_btnF2D ui-button' id='"+myself.name+"_btnDestToSource' value='<-'/><br/>";
		html+="   <input type='button' class='"+myself.name+"_btnF2D ui-button' id='"+myself.name+"_btnDestToSourceAll' value='<<'/>";
		html+="  </div></td>";
		html+="  <td style='width:45%'><div>"+selectDestHTML+"</div></td>";
		html+=" </tr>";
		html+=" <tr>";
		html+=" <td colspan='3' style='padding: 3px' class='fg-toolbar ui-toolbar ui-widget-header ui-corner-bl ui-corner-br'><div>"
		html+="   <input type='button' id='"+myself.name+"_btnGoFirst' class='ui-button' value='|<'/>";
		html+="   <input type='button' id='"+myself.name+"_btnGoPrev' class='ui-button' value='<<'/>";
		html+="   <input type='button' id='"+myself.name+"_btnGoNext' class='ui-button' value='>>'/>";
		html+="   <input type='button' id='"+myself.name+"_btnGoLast' class='ui-button' value='>|'/></div>";	
		html+="   <table><tr><td style='width:80%'><span id='"+myself.name+"_pageSel'/><span id='"+myself.name+"_pageInfo'/><span id='"+myself.name+"_visiblesInfo'/></td>";		
		html+="   <td style='width:20%'><div style='text-align:right; vertical-align:text-top' id='"+myself.name+"_itemsDest'>0 items</div></td></tr></table>";		
		html+="  </td>";
		html+=" </tr>";
		html+="</table>";
		
		
		myself.setupPages();

		ph.html(html);
		myself.refreshSource();
		myself.refreshPageButtons();
		
		$("#"+myself.name+"_lstDest").attr("height",$("#"+myself.name+"_lstSource").attr("height"));
		$("#"+myself.name+"_txtSearch").keyup(function() {
			myself.txtSearch=$(this).val();
			$(this).attr("disabled","disabled");
			myself.refreshSource();
			$(this).removeAttr("disabled");
		});
		$("#"+myself.name+"_txtSearchAll").keyup(function() {
			if ($(this).val().length>=myself.minLengthForSearchAll) 
				$("#"+myself.name+"_btnSearchAll").removeAttr("disabled");
			else
				$("#"+myself.name+"_btnSearchAll").attr("disabled","disabled");
		});
		$("#"+myself.name+"_btnSearchAll").click(function(){
			myself.filterDataArray($("#"+myself.name+"_txtSearchAll").val());
			$("#"+myself.name+"_btnSearchAllClear").removeAttr("disabled");
		});
		$("#"+myself.name+"_btnSearchAllClear").click(function(){
			Dashboards.incrementRunningCalls();
			$("#"+myself.name+"_txtSearchAll").val("");
			$("#"+myself.name+"_btnSearchAll").attr("disabled","disabled");
			$("#"+myself.name+"_btnSearchAllClear").attr("disabled","disabled");
			myself.dataArray = $.merge([], myself.dataArrayFull);
			myself.dataLength=myself.dataArray.length;
			myself.setupPages();
			myself.refreshSource();
			myself.refreshPageButtons();
			Dashboards.decrementRunningCalls();	
		});
		$("#"+myself.name+"_btnGoFirst").click(function() {
			myself.goFirstPage();
		});
		$("#"+myself.name+"_btnGoPrev").click(function() {
			myself.goPrevPage();
		});
		$("#"+myself.name+"_btnGoNext").click(function() {
			myself.goNextPage();
		});
		$("#"+myself.name+"_btnGoLast").click(function() {
			myself.goLastPage();
		});
		$("."+myself.name+"_btnF2D").click(function(event) {
			Dashboards.incrementRunningCalls();
			var id=$(event.target).attr('id');
			var sFrom = (id == myself.name+"_btnSourceToDest" || id == myself.name+"_btnSourceToDestAll") ? myself.name+"_lstSource" : myself.name+"_lstDest";
			var sTo = (id == myself.name+"_btnSourceToDest" || id == myself.name+"_btnSourceToDestAll") ? myself.name+"_lstDest" : myself.name+"_lstSource";
			var all= (id == myself.name+"_btnSourceToDestAll" || id == myself.name+"_btnDestToSourceAll") ? "" : ":selected";
			
			var selectedItems=$("#"+sFrom + " option"+all);
			if(sTo == myself.name+"_lstDest") {
				var out=[];
				$.each(selectedItems, function(key, e){
					out.push('<option value="' + e.value + '">' + e.text + '</option>');
				});
				$("#"+sTo).append(out.join(""));
				if (myself.keepDestSorted) {
					var items= $("#"+myself.name+"_lstDest option");
					items.sort(function(a,b) {
						aa=a.text;
						bb=b.text; 
						if (myself.sortDestByKey) {
							aa=a.value;
							bb=b.value;
						}
						if (aa > bb) return 1;
						else if (aa < bb) return -1;
						else return 0;
					});
					$("#"+myself.name+"_lstDest").empty().append(items);
					myself.setItemsDestInfo(items,myself.name+"_itemsDest");
				} else {
					myself.setItemsDestInfo($("#"+myself.name+"_lstDest option"),myself.name+"_itemsDest");
				}
			}
			selectedItems.remove();
			if(sTo == myself.name+"_lstSource") {
				myself.setItemsDestInfo($("#"+myself.name+"_lstDest option"),myself.name+"_itemsDest");	
				myself.refreshSource();
			} else {
				var cant=$("#"+myself.name+"_lstSource option").size();
				$('#'+myself.name+"_visiblesInfo").html(" [visible: "+cant+"]");
			}
			Dashboards.decrementRunningCalls();
			
		});
		Dashboards.decrementRunningCalls();
	},



	filterDataArray: function(txtGF) {
		Dashboards.incrementRunningCalls();
		this.dataArray=[];
		var myArray=this.dataArrayFull;
		var vid = this.valueAsId==false?false:true;
		var lstDestItems=$("#"+this.name+"_lstDest option");
		for(var i= 0, len  = myArray.length; i < len; i++){
			if(myArray[i]!= null && myArray[i].length>0) {
				var ivid = vid || myArray[i][0] == null;
				var value, label;
				if (myArray[i].length > 1) {
					value = myArray[i][ivid?1:0];
					label = myArray[i][1];
				} else {
					value = myArray[i][0];
					label = myArray[i][0];
				}
				if (label.toLowerCase().indexOf(txtGF.toLowerCase()) != -1) { // match with global search text
					var ins=true;
					$.each(lstDestItems, function(key, e){
						if (value==e.value) {
							ins=false;
							return false;
						}
					});
					if (ins) {
						this.dataArray.push([value,label]);
					}
				}
			}
		}
		this.dataLength=this.dataArray.length;
		this.setupPages();
		this.refreshSource();
		this.refreshPageButtons();
		Dashboards.decrementRunningCalls();	
	},
	setItemsDestInfo: function(items, id) {
		$("#"+id).html(items.length+' items');	
		var currentVal = Dashboards.getParameterValue(this.parameter);
		currentVal = typeof currentVal == 'function' ? currentVal(): currentVal;
		if (currentVal!='undefined') {
			var ini= this.initParameterString;
			var fin= this.endParameterString;
			var join= this.joinParameterString;
			var out=[];
			myself=this;
			$.each(items, function(key, e){
				if (myself.fillParameterWithId) 
					out.push(e.value);
				else
					out.push(e.text);
			});
			var t=ini;
			t+=out.join(join);
			t+=fin;
			Dashboards.setParameter(this.parameter, t);
		}
	},
	txtSearch : ''
});
