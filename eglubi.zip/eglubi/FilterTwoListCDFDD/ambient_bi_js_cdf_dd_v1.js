
// Open New PUC Tab
function openReport(reportTabName, reportUrl){
var colParam = $(this).text();
//alert("Parameter passed: "+colParam);
top.mantle_openTab(reportTabName, "tabname", 'http://localhost:8080/pentaho/content/reporting/reportviewer/report.html?solution=ambientbi&path=%2Freports&name=product_sales_report.prpt&PARAM_PRODUCTLINE='+colParam);
} 

// Randon string generator
function randomString() {
    var chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz";
	var string_length = 8;
	var randomstring = '';
	for (var i=0; i<string_length; i++) {
		var rnum = Math.floor(Math.random() * chars.length);
		randomstring += chars.substring(rnum,rnum+1);
	}
	return randomstring;
}

// Sparkline generator
function renderSparklines(tableComponent, colNumber, lineWidth, color) {
    if (lineWidth=='undefined')
        lineWidth=1;
    if (color=='undefined')
        color='black';

    var sparklineRows = $('#'+tableComponent+' td:nth-child('+colNumber+')');
    var count = 0;
    
    // fixed by (Magm) eGluBI
    var datas=new Array(sparklineRows.length); 

    sparklineRows.each(function(){ 
        datas[count] = $(this).text().split(",");
        count++;
        $(this).empty();
    });
    count = 0;
    // end fixed by (Magm) eGluBI
    
    sparklineRows.each(function(){
        var ph = $(this);
        var sparklineData = ph.text();
	    var data=datas[count];  // fixed by (Magm) eGluBI
        var n = data.length,
            w = ph.width(),
            h = 10,
            min = pv.min.index(data),
            max = pv.max.index(data);
        
            //console.log("min "+min);
            //console.log("max "+max);
        count++; // fixed by (Magm) eGluBI
        var random_val = randomString();
    
        ph.append("<div id='sparkline-"+random_val+"-"+count+"'></div>");
    
        //console.log("count "+count);
    
        var vis = new pv.Panel()
            .canvas("sparkline-"+random_val+"-"+count)
            .width(w)
            .height(h)
            .margin(2);
    
        vis.add(pv.Line)
            .data(data)
            .left(pv.Scale.linear(0, n - 1).range(0, w).by(pv.index))
            .bottom(pv.Scale.linear(data).range(0, h))
            .strokeStyle(color)
            .lineWidth(lineWidth);        

        vis.render();
    });

} 

// Data Bar generator
function renderBars(tableComponent, colNumber) {
    
    /* get the colum we are interested in. In this case its the third column of the
       r1c1 layout div */
       
   var salesRows = $('#'+tableComponent+' td:nth-child('+colNumber+')');
   
   var datas=new Array(salesRows.length);  // fixed by (Magm) eGluBI
   var count=0;                            // fixed by (Magm) eGluBI

   /* now we loop through each row in the column and do a little jquery magic */
   
   var rgabsMax=0;
   
   salesRows.each(function(i,vv){
	datas[count]=$(this).text();       // fixed by (Magm) eGluBI
	count++;                           // fixed by (Magm) eGluBI	
	var v = Math.abs($(this).text());
    if(v>rgabsMax){
        rgabsMax = v;
    }
	$(this).empty();                   // fixed by (Magm) eGluBI
   });
   count=0;                            // fixed by (Magm) eGluBI
   salesRows.each(function(){
    var ph = $(this);
    var wtmp = ph.width();
    var htmp = 12;
   
    var value = datas[count];          // fixed by (Magm) eGluBI
	count++;                           // fixed by (Magm) eGluBI
   
    var paper = Raphael(this, wtmp, htmp);
   
    var xx = pv.Scale.linear(0,rgabsMax).range(0,wtmp);
   
    var leftVal=0, rightVal=parseFloat(value);
    if(leftVal>rightVal){
        leftVal = value;
        rightVal = 0;
    }
   
   	var c = paper.rect(xx(leftVal), 0, xx(rightVal) - xx(leftVal), htmp);
   
   	c.attr({
   		fill: "90-#66A4D6-#448FC8",
   		stroke: null,
   		title: "Value: "+ value
   	});
   });
}
