if (Meteor.isClient) {
  Template.datosPersonales.isDetalleVisible = function () {
    return Session.equals('detalleVisible',true);
  };
  Template.datosPersonales.events({
    'click #btnVerDetalle' : function () {
      if (Session.equals('detalleVisible',true))
        Session.set('detalleVisible',false);
      else
        Session.set('detalleVisible',true);
    }
  });
}
