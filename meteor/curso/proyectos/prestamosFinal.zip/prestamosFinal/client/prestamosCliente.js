  Accounts.ui.config({
    passwordSignupFields: 'USERNAME_AND_OPTIONAL_EMAIL'
  });
  Meteor.subscribe("categorias");
  Meteor.autosubscribe(function() {
    Meteor.subscribe("detalle",
                    Session.get('listaActual'));
  });

  Template.categorias.isUserLogin=function() {
    return Meteor.userId();
  };
  Template.categorias.listaDeCategorias = function () {
    return listas.find({}, {sort: {categoria: 1}});
  };
  Session.set('agregandoCategoria', false);
  Template.categorias.isAgregandoCategoria = function () {
    return Session.equals('agregandoCategoria',true);
  };
  Template.categorias.events({
    'click #btnNvaCat': function (e, t) {
      Session.set('agregandoCategoria', true);
      Meteor.flush();
      focusText(t.find("#agregaCategoriaTxt"));
    }, 
    'keyup #agregaCategoriaTxt': function (e,t){
      if (e.which === 13) {
        var valor = String(e.target.value || "");
        if (valor) {
          listas.insert({categoria:valor,
                    duenio:Meteor.userId()});
          Session.set('agregandoCategoria', false);
        }
      }
    },
    'focusout #agregaCategoriaTxt': function(e,t){
      Session.set('agregandoCategoria',false);
    },
    'click .categoria': function(e,t){
        Session.set('listaActual',this._id);
    }
  });

  Template.detalle.items = function () {
    if (Session.equals('listaActual',null))
      return null;
    else {
      var categs = listas.findOne({_id:Session.get('listaActual')});
      if (categs&&categs.items) {
        for(var i = 0; i<categs.items.length;i++) {
          var d = categs.items[i]; 
          d.prestado = d.prestadoA ? d.prestadoA : "libre"; 
          d.clasePrestamo = d.prestadoA ? "label-important" : "label-success";
        }
        return categs.items;
      }
    }
  };

  Template.detalle.isListaSeleccionada = function() {
   return ((Session.get('listaActual')!=null) && (!Session.equals('listaActual',null)));
  };
  Template.categorias.estadoLista = function(){
    if (Session.equals('listaActual',this._id))
      return "";
    else
      return " btn-inverse";
  };

 Template.detalle.events({
    'click #btnAgregarItem': function (e,t){
      Session.set('agregandoALista',true);
      Meteor.flush();
      focusText(t.find("#itemPorAgregarTxt"));
    },
    'keyup #itemPorAgregarTxt': function (e,t){
      if (e.which === 13) {
        agregarItem(Session.get('listaActual'),e.target.value);
        Session.set('agregandoALista',false);
      }
    },
    'focusout #itemPorAgregarTxt': function(e,t){
      Session.set('agregandoALista',false);
    },
    'click .itemBorrar': function(e,t){
      borrarItem(Session.get('listaActual'),e.target.id);
    },
    'click .prestado' : function(e,t){
      Session.set('editandoPrestadoA',this.nombre);
      Meteor.flush();
      focusText(t.find("#prestadoATxt"),this.prestadoA);
    },
    'keyup #prestadoATxt': function (e,t){
      if (e.which === 13) {
        modificarPrestadoA(Session.get('listaActual'),this.nombre,
        e.target.value);
        Session.set('editandoPrestadoA',null);
      }
      if (e.which === 27) {
        Session.set('editandoPrestadoA',null);
      }
    },
    'focusout #prestadoATxt': function(e,t){
      Session.set('editandoPrestadoA',null);
    }
  });
  Template.detalle.isAgregandoALista = function(){
    return (Session.equals('agregandoALista',true));
  };
  Template.detalle.isEditandoPrestadoA = function(){
    return (Session.equals('editandoPrestadoA',this.nombre));
  };

  function focusText(i,val) {
    i.focus();
    i.value = val ? val : "";
    i.select();
  };


function agregarItem(idLista, nombreItem){
  if (!nombreItem && !idLista)
    return;
  listas.update({_id:idLista},
    {$addToSet:{items:{nombre:nombreItem}}});
}

function borrarItem(idLista, nombreItem){
  if (!nombreItem && !idLista)
    return;
  listas.update({_id:idLista},
    {$pull:{items:{nombre:nombreItem}}});
}

function modificarPrestadoA(idLista, nombreItem, prestadoA){
  var l = listas.findOne({"_id":idLista , "items.nombre":nombreItem});
  if (l&&l.items) {
    for (var i = 0; i<l.items.length; i++) {
      if (l.items[i].nombre === nombreItem){
        l.items[i].prestadoA = prestadoA;
      }
    }
  listas.update({"_id":idLista},{$set:{"items":l.items}});
  }
}