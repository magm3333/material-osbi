  Meteor.publish("categorias", function() {
    return listas.find({duenio:this.userId},{fields:{categoria:1}});
  });
  Meteor.publish("detalle", function(idCategoria){
    return listas.find({_id:idCategoria});
  });
  Meteor.startup(function () {
    // code to run on server at startup
  });