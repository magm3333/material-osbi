listas = new Meteor.Collection("Listas");

function isAdmin(idUsuario) {
  var usuarioAdmin = Meteor.users.findOne({username:"admin"});
  return (idUsuario && usuarioAdmin && idUsuario === usuarioAdmin._id);
}

listas.allow({
  insert: function(idUsuario, documento){
    return isAdmin(idUsuario) || (idUsuario && documento.duenio === idUsuario);
  },
  update: function(idUsuario, documento, campos, modifier){
    return isAdmin(idUsuario) || (idUsuario && documento.duenio === idUsuario);
  },
  remove: function(idUsuario, documentos){
    return isAdmin(idUsuario) || (idUsuario && documento.duenio === idUsuario);
  }
});