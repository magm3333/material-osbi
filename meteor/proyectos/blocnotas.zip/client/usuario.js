Template.usuarioAutenticado.events({
	"click #cerrarSesion":function(event,template){
		Meteor.logout(function(err){
		});
	}
});

Template.usuarioNoAutenticado.events({
	"click #iniciarSesion":function(event,template){
		Meteor.loginWithGoogle({
			requestPermissions: ['profile']
			}, function(err){
		});
	}
});