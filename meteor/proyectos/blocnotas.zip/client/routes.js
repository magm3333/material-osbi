Meteor.Router.add({
	'/': 'home',
  '/bookmarklet/:id':function(p){
    //http://localhost:3000/bookmarklet/anotar?texto=un%20texto
    var pares=[];
    var qs={};
    if (this.querystring){
      pares=this.querystring.split("&");
      _(pares).each(function(o){
        var v=o.split("=");
        qs[v[0]]=v[1];
      });
      if(qs.texto && qs.texto.length>0) {
        Session.set('textFromBookmarklet',decodeURI(qs.texto));
      }
    }
    history.pushState( {}, document.title, window.location.origin );
    return 'home';
  }
});


Meteor.Router.filters({
  'checkLoggedIn': function(page) {
    if (Meteor.loggingIn()) {
      return 'loading';
    } else if (Meteor.user()) {
      return page;
    } else {
      return 'usuarioNoAutenticado';
    }
  }
});

Meteor.Router.filter('checkLoggedIn');
