Meteor.Router.add({
  '/': 'home'
});