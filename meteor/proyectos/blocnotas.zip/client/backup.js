Template.backups.files = function() {
    //show all files that have been published to the client, with most recently uploaded first
    return backupsFS.find({}, { sort: { uploadDate:-1 } });
};
Template.backups.events({
	"click .descargabck": function(event){
		backupsFS.retrieveBlob($(event.target).data("id"), function(fileItem) {
      if (fileItem.blob)
        saveAs(fileItem.blob, $(event.target).data("filename"));
      else
        saveAs(fileItem.file, $(event.target).data("filename"));
    });
	},
	"click .eliminabck": function(event){
		backupsFS.remove($(event.target).data("id"));
	}
});
