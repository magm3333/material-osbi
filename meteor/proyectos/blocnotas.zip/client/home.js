Toast.defaults.displayDuration = 3000;
Toast.defaults.fadeOutDuration = 800;
Toast.defaults.width = '800px'

// Fin Template nota
Template.nota.events({
	"click .tagVisual":function(event){
		event.stopPropagation();
		event.preventDefault();
		Session.set('tagForSearch',event.target.innerHTML);
	}
});
// Fin Template nota

// Template Contenido
Template.contenido.cantidadNotas=function() {
	return Session.get('cantidadNotas');
}

Template.contenido.filtrosAplicados=function() {
	var r="";
	if(Session.get('textoFiltro'))
		r= "Texto="+Session.get('textoFiltro');
	if(Session.get('tagForSearch'))
		r+= (r.length>0? " y " : "")+ "Tag="+Session.get('tagForSearch');
	if(r.length>0)
		r="<span class='label label-success'>Filtros aplicados: "+r+"</span>";
	return r;
}


Template.contenido.rendered=function() {
	var txt=Session.get("textFromBookmarklet");
	if(txt && txt.length>0) {
		Session.set("textFromBookmarklet",false);
		nuevaNota(txt,["bookmarklet"]);
		Toast.info("Nuevo nota creada desde Bookmarklet!");
	}
}

Template.contenido.listaDeNotas = function () {
	var ids=Session.get('idsFromSearch');
	var tag=Session.get('tagForSearch');

	var filter1=false;
	var filter2=false;
	if(ids && ids.length>0)
		filter1='{"_id":{"$in":'+JSON.stringify(ids)+'}}';
	if (tag)
		filter2='{"tags":"'+tag+'"}';
	var filter='{}';
	if(filter1 && filter2)
		filter='{"$and":['+filter1+','+filter2+']}';
	else
		filter=filter1 || filter2 || filter;
	filter=JSON.parse(filter);

	n= notas.find(filter,{sort:{timestamp:-1}});

	var r=[];
	n.forEach(function(o) {
		if(o.tags && o.tags.length>0){
			o.tagsStr=o.tags.join();
			var tagsStrLinks="";
			_(o.tags).each(function(t){
				tagsStrLinks+="<span class='label tagVisual' title='Click para filtar por este tag'>"+t+"</span>";
			});
			o.tagsStrLinks=tagsStrLinks;
		} else {
			o.tagsStr=[];
			o.tagsStrLinks="";
		}
		r.push(o);
	});
	Session.set('cantidadNotas',n.count());
	return r;
};

Template.contenido.events({
	"click .nota":function(event){
		enableEdit(event.target);
	},
	"click .tags":function(event){
		enableEdit(event.target);
	}
});
// Fin Template Contenido

// Templates del Menú de opciones
Template.btnEnviarMailNota.events({
	"click .enviarMailNota":function(event){
		var idN=getIdNota(event.target);
		$("#idNotaEmail").val(idN);
		$("#enviarMail" ).dialog({
      autoOpen: false,
      width: 550,
      height: 350,
      title: 'Compartir la nota por mail',
      show: {
        effect: "blind",
        duration: 500
      },
      hide: {
        effect: "explode",
        duration: 500
      }
    });
    var user=Meteor.users.findOne({_id:Meteor.userId()});
		var mails=user.profile.mailsUsados || [];
		$("#mailTo").val("");
		$("#asunto").val("");
    $("#mailTo").select2({tags:mails});
		$("#enviarMail").dialog("open");
	}
});
Template.btnEliminarNota.events({
	"click .eliminarNota":function(event){
		//notas.remove({_id:getIdNota(event.target)});
		notas.update({_id:getIdNota(event.target)},{$set:{"eliminado":true}});
	}
});

Template.btnGuardarNota.events({
	"click .guardarNota":function(event){
		destroyEditors(getIdNota(event.target));
	}
});

Template.btnEditarNota.events({
	"click .editarNota":function(event){
		enableEdit(event.target);
	}
});

Template.menuOpciones.rendered = function () {
	$("#filterAndOr").wrap('<div class="switch" data-on-label="OR" data-off-label="AND"/>').parent().bootstrapSwitch();
};
Template.menuOpciones.preserve(["#filterAndOr"]);

Template.menuOpciones.events({
	"click #nuevaNota":function(event){
		nuevaNota("");
	},
	"click #btnBackupStr":function(event){
		window.open("/backup?uid="+Meteor.userId(),"_blank","location=0,menubar=0");
	},
	"click #btnBackupZip":function(event){
		Meteor.call('backup', Meteor.userId(),
			function (error, result) { 
				if (error) {
					alert(error);
				} else {
					console.log(result);
					Toast.info("Se creó el backup: "+result);
				}
			}
		);
	},
	"click #btnVerBackups":function(event){
		$( "#listaBackups" ).dialog({
      autoOpen: false,
      width: 400,
      height: 400,
      title: 'Copias de Seguridad',
      show: {
        effect: "blind",
        duration: 500
      },
      hide: {
        effect: "explode",
        duration: 500
      }
    });
		$("#listaBackups").dialog("open");
	},
	"focus #txtBuscar":function(event){
		if (!Session.equals('idNotaActual',null)) {
			destroyEditors(Session.get('idNotaActual'));
		}
	},
	"keyup #txtBuscar":function(event){
		if (event.which === 13) {
			var valor = String(event.target.value || "");
			if(valor.length>2) {
				var operador=" [AND]";
				if ($("#filterAndOr").is(':checked'))
					operador=" [OR]";
				Meteor.call('search', Meteor.userId(), valor, !$("#filterAndOr").is(':checked'),
					function (error, result) { 
						if (error) {
							alert(error);
						} else {
							if(result && result.length>0) {
								Session.set('textoFiltro',valor + operador);
								Session.set('idsFromSearch',result);
							} else {
								Toast.info("No se encontraron notas con este criterio de búsqueda");
							}
						}
					}
				);
			}
		}
	},
	"click #btnVerTodo":function(event){
		$("#txtBuscar").val("");
		Session.set('textoFiltro',false);
		Session.set('idsFromSearch',false);
		Session.set('tagForSearch',false);
	}
});
// Fin Templates del Menú de opciones

// Funciones utilitarias 
function enableEdit(contenedor) {
	var idNota=getIdNota(contenedor);
	if (Session.equals('idNotaActual',idNota)) {
		return;
	}
	if (!Session.equals('idNotaActual',null)) {
		destroyEditors(Session.get('idNotaActual'));
	}
	Session.set('idNotaActual',idNota);
	createEditors(idNota);
}

editor=false;
function createEditors(idNota) {
	var idDivNota='nota'+idNota;
	var classInputTags='tagedit'+idNota;
	var idContenedorTags='tags'+idNota;
	var idSpanTagRO='tagro'+idNota;
	var idBtnGuardarNota="guardarNota"+idNota;
	var idBtnEditarNota="editarNota"+idNota;
	editor = CKEDITOR.replace(document.getElementById(idDivNota));
	
	var wte=$('#'+idContenedorTags).outerWidth();
	$('#'+idContenedorTags).hide();
	
	var inputTag=$("."+classInputTags ,$("#"+idNota));

	tagEditor= $(inputTag).tagsInput({
		autocomplete_url: '/autocomplete?uid='+Meteor.userId(),
    	autocomplete:{selectFirst:true,width:'100px',autoFill:true},
    	'defaultText':'nuevo tag',
    	'height':'305px',
    	'width':wte+'px',
    	onChange:function(e){
    		var valStr=$(inputTag).val();
    		$('#'+idSpanTagRO).html(valStr);
    	},onAddTag:function(tag){
    		addTag(tag);
    	},onRemoveTag:function(tag){
    		removeTag(tag);
    	}
	});
	$('#'+idBtnGuardarNota).show();
	$('#'+idBtnEditarNota).hide();
}

function removeTag(tag){
	r=tags.findOne({},{tags:1});
  	if(r && r.tags) {
  		var aTags=[];
  		_(r.tags).each(function(o){
  			if(o.t==tag) {
  				o.c--;
  			}
  			if(o.c>0){
  				aTags.push(o);
  			}
  		});
  		tags.update({_id:r._id},{$set:{"tags":aTags}});
  	}
}

function addTag(tag){
  	r=tags.findOne({},{tags:1});
  	if(r && r.tags) {
  		var aTags=r.tags;
  		var agregar=true;
  		_(aTags).each(function(o){
  			if(o.t==tag) {
  				o.c++;
  				agregar=false;
  			}
  		});
  		if(agregar) {
  			aTags.push({t:tag,c:1});
  		}
  		tags.update({_id:r._id},{$set:{"tags":aTags}});
  	} else {
  		tags.insert({"user":Meteor.userId(),"tags":[]});
  	}
}

function destroyEditors(idNota) {
	if(editor) {
		try {
			editor.destroy();
		} catch(e) {}
	}
	var idBtnGuardarNota="guardarNota"+idNota;
	var idBtnEditarNota="editarNota"+idNota;
	var idDivNota='nota'+idNota;
	var idSpanTagRO='tagro'+idNota;
	var spanRO=$('#'+idSpanTagRO);
	var idContenedorTags='tags'+idNota;
	$('#'+idContenedorTags).show();
	$('.tagsinput',$('#'+idNota)).remove();
	var tagsArray=[];
	if(spanRO.html() && spanRO.html().length>0)
		tagsArray=spanRO.html().split(",");
	var notaTxt=$('#'+idDivNota).html();
	$('#'+idBtnGuardarNota).hide();
	$('#'+idBtnEditarNota).show();
	try {
		notas.update({"_id":idNota},{$set:{"nota":notaTxt,"tags":tagsArray}});
	} catch(e) {
		console.log(e);
	}
}

function getIdNota(contenedor) {
	return $($(contenedor).closest('.contenedorNota')[0]).attr('id');
}

function nuevaNota(text, tags) {
	if (!Session.equals('idNotaActual',null)) {
		destroyEditors(Session.get('idNotaActual'));
	}
	var tgs=[];
	if(tags)
		tgs=tags;
	notas.insert(notas.insert({
		user:Meteor.userId(),
		timestamp: new Date(),
		nota:text,
		tags:tgs
	}));
}
// Fin funciones utilitarias