Template.enviarMail.events({
	"click #btnSendEmail":function(event){
		if($("#mailTo").val().length<7){
			Toast.error("Ingrese al menos una dirección de correo para destinatario.");
			$("#mailTo").focus();
			return false;
		}
		var profile=Meteor.users.findOne({_id:Meteor.userId()}).profile;

		var mailsUsados=profile.mailsUsados || [];
		var mailsUsadosFinal=mailsUsados;
		var destinatarios=$("#mailTo").val().split(',');
		_(destinatarios).each(function(d){
			var agrega=true;
			_(mailsUsados).each(function(u){
				if(d==u){
					agrega=false;
					return;
				}
	  	});
	  	if(agrega) 
				mailsUsadosFinal.push(d);
  	});
		profile.mailsUsados=mailsUsadosFinal;
		Meteor.users.update({_id:Meteor.userId()},{$set:{"profile":profile}});

		var asunto=$("#asunto").val() || "Nota compartida desde blocdenotas.meteor.com";

		$("#enviarMail").dialog("close");
		Toast.info("Compartiendo la nota por mail...");
		Meteor.call('sendEmail',
			destinatarios,
			$("#idNotaEmail").val(),
			function (error, result) { 
				if (error) {
					Toast.error("Error compartiendo la nota");
				} else {
					Toast.info("Nota compartida con éxito!");
				}
			}
		);
		return false;
	}
});

Template.enviarMail.rendered=function() {
	$("#frmEnviarMail").submit(function(){
   		return false;
  });
};