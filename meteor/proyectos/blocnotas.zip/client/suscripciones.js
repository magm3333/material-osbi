Meteor.subscribe("tags");
Meteor.subscribe("notas");
Meteor.subscribe("backupsFS"); 
