 Meteor.subscribe("tags");
 Meteor.subscribe("notas");