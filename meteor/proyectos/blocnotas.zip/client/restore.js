Template.formRestore.events({
  "submit #restoreBackup": function (e, tmpl) {
    e.preventDefault();
    var fileInput = tmpl.find('input[type=file]');
    var form = e.currentTarget;
    var file;
    for (var i = 0; i < fileInput.files.length; i++) {
      file = fileInput.files[i];
      MeteorFile.read(file, function (err, meteorFile) {
        Meteor.call("uploadBackup", meteorFile, function (err, result) {
          if (err) {
            throw err;
          } else {
            console.log(result);
            if(result=="error") {
              Toast.error("Archivo erroneo");
              form.reset();
            } else if(!result.json) {
              Toast.error("El archivo no contiene un backup del bloc de notas");
              form.reset();
            } else {
              $("#resultadoRestore").val(JSON.stringify(result));
              Toast.info("Archivo subido correctamente.");
              $("#restaurar").dialog("close");
              $("#restaurarFinal" ).dialog({
                autoOpen: false,
                width: 600,
                height: 250,
                title: 'Restaurar - Paso 2/2 (confirmar)',
                show: {
                  effect: "blind",
                  duration: 500
                },
                hide: {
                  effect: "explode",
                  duration: 500
                }
              });
              $("#restaurarFinal").dialog("open"); 
            }
          }
        });
      });
    }
    return false;
  }
});

Template.procesarRestore.events({
  "click #btnProcesarRestore": function (e, tmpl) {
    var arg=JSON.parse($("#resultadoRestore").val());
    console.log(arg);
    Meteor.call("processBackup", arg, Meteor.userId(), function(err, result){
      if (err) {
          throw err;
      } else {
        if(result.err) {
          Toast.error("Error restaurando copia de seguridad");
        } else {
          Toast.info("Se restauraron "+
            (result.insert+result.update)+" notas. ("+
            result.insert+ " nuevas y "+
            result.update+ " modificadas)");
           $("#restaurarFinal").dialog("close"); 
        }
      }
    });
  }
});