/*
{
	user:"ZcdqJN5eJu9Da87qb",
	nota:"",
	timestamp: "Thu Jun 27 2013 20:06:12 GMT-0300 (ART)",
	tags:["java","javascript","meteor","pentaho","mysql"]
}
*/
tags = new Meteor.Collection("Tags");

/*
{
	user:"ZcdqJN5eJu9Da87qb",
	nota:"Hola <b>mundo</b>",
	tags:["prueba","test"]
	nuevo
	tags:[{t:"prueba",c:1},{t:"test",c:3}]
}
*/
notas = new Meteor.Collection("Notas");

backupsFS = new CollectionFS('backupsFS');

notas.allow({
  insert: function(idUsuario, documento){
    return (idUsuario && documento.user === idUsuario);
  },
  update: function(idUsuario, documento, campos, modifier){
    return (idUsuario && documento.user === idUsuario);
  },
  remove: function(idUsuario, documentos){
    return (idUsuario && documento.user === idUsuario);
  }
});
tags.allow({
  insert: function(idUsuario, documento){
    return (idUsuario && documento.user === idUsuario);
  },
  update: function(idUsuario, documento, campos, modifier){
    return (idUsuario && documento.user === idUsuario);
  },
  remove: function(idUsuario, documentos){
    return (idUsuario && documento.user === idUsuario);
  }
});

backupsFS.allow({
    insert: function(userId, file) { 
      return userId && file.owner === userId; 
    },
    update: function(userId, files, fields, modifier) {
        return _.all(files, function (file) {
            return (userId == file.owner);
        });  
    },
    remove: function(userId, files) { 
      return true; 
    }
});

