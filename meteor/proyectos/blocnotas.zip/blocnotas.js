/*
{
	user:"ZcdqJN5eJu9Da87qb",
	nota:"",
	timestamp: "Thu Jun 27 2013 20:06:12 GMT-0300 (ART)",
	tags:["java","javascript","meteor","pentaho","mysql"]
}
*/
tags = new Meteor.Collection("Tags");

/*
{
	user:"ZcdqJN5eJu9Da87qb",
	nota:"Hola <b>mundo</b>",
	tags:["prueba","test"]
	nuevo
	tags:[{t:"prueba",c:1},{t:"test",c:3}]
}
*/
notas = new Meteor.Collection("Notas");