Accounts.loginServiceConfiguration.remove({
	service: "google"
});

Accounts.loginServiceConfiguration.insert({
	service: "google",
	clientId: "441624260670-ho99afe786j48krjpsvp9o7sk2tuqfk3.apps.googleusercontent.com",
	secret: "sv8GuVQycnyCVLByoOe3PAxg"
})

/* blocdenotas.meteor.com
{
	service: "google",
	clientId: "441624260670-ho99afe786j48krjpsvp9o7sk2tuqfk3.apps.googleusercontent.com",
	secret: "sv8GuVQycnyCVLByoOe3PAxg"
},
*/

/* localhost:3000
{
	service: "google",
	clientId: "441624260670-5p0k5et2ns9pnlm8cfj4fec9dkpgtp8b.apps.googleusercontent.com",
	secret: "3LMwIOXfPqGhyntL_5oeH43h"
}
*/

//TODOs


// hacer filtro pot tags
// cuando se elimine una nota hay que actualizar tags
// hacer login github, FB, Yahoo! y otros
// manejar usuarios propios
// hacer que los tags se vean mejor y hacer links para busquedas
//MEJORAR EL ASPECTO!!!!