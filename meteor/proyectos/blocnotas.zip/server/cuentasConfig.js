
Accounts.loginServiceConfiguration.remove({
	service: "google"
});

if(process.env.ROOT_URL=='http://localhost:3000') {
	Accounts.loginServiceConfiguration.insert( {
		service: "google",
		clientId: "441624260670-5p0k5et2ns9pnlm8cfj4fec9dkpgtp8b.apps.googleusercontent.com",
		secret: "3LMwIOXfPqGhyntL_5oeH43h"
	})
}else{
	Accounts.loginServiceConfiguration.insert( {
	service: "google",
	clientId: "441624260670-ho99afe786j48krjpsvp9o7sk2tuqfk3.apps.googleusercontent.com",
	secret: "sv8GuVQycnyCVLByoOe3PAxg"
	})
}

//TODOs

// que se mantenga el estado del or and (ver preserve en el template)
// cuando se elimine una nota hay que actualizar tags
// unificar cuentas
// mavegador de tags
//MEJORAR EL ASPECTO!!!!