Meteor.publish("tags", function() {
	return tags.find({user:this.userId},{reactive: false});
});
Meteor.publish("notas", function() {
	return notas.find({user:this.userId},{sort:{timestamp:-1}});
});