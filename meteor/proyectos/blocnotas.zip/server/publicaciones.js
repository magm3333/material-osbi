Meteor.publish("tags", function() {
	return tags.find({user:this.userId},{reactive: false});
});
Meteor.publish("notas", function() {
	return notas.find({"$and":[{user:this.userId}, { "$or": [{eliminado:{"$exists":false}},{eliminado:false}] }]},{sort:{timestamp:-1}});
});
Meteor.publish('backupsFS', function() {
    if (this.userId) {
        return backupsFS.find({ owner: this.userId });
    }
});