
Meteor.Router.add({
  '/autocomplete':function(){
  	var term=this.request.query.term;
  	r=tags.findOne({user:this.request.query.uid},{tags:1});
  	if(r && r.tags) {
  		var tagsMatch = _(r.tags).filter(function(o) { 
  			return startsWith(o.t, term);
  		});
  		var result=[];
  		_(tagsMatch).each(function(o){
  			result.push({label:o.t});
  		});
  		return JSON.stringify(result);
  	}else{
  		return '[]';
  	}
  },
  '/backup':function(){
    var r=notas.find({user:this.request.query.uid},{sort:{timestamp:-1}});
    var bck=[]; 
    r.forEach(function(o){
      bck.push({nota:o.nota,tags:o.tags,timestamp:o.timestamp});
    });
    return JSON.stringify(bck);
  }
});


function startsWith(val, text){
  return val.slice(0, text.length) == text;
};