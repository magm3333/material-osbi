process.env.MAIL_URL="smtp://postmaster%40blocdenotas.mailgun.org:blocdenotas@smtp.mailgun.org:587";
Meteor.startup(function () {
  Meteor.methods({
    search: function (uid, key, porAnd) {
    	var r=notas.find({user:uid},{sort:{timestamp:-1}});
      var ids=[];
      var keys=key.split(' ');
  		r.forEach(function(o){
  			var n=o.nota.replace(/(<\?[a-z]*(\s[^>]*)?\?(>|$)|<!\[[a-z]*\[|\]\]>|<!DOCTYPE[^>]*?(>|$)|<!--[\s\S]*?(-->|$)|<[a-z?!\/]([a-z0-9_:.])*(\s[^>]*)?(>|$))/gi, '');
  			n=n.replace(/&\w+?;/g,'');
  			if(n && n.length>0) {
          var esta=true;
          if(porAnd) {
            _.each(keys, function(k){
              if(n.indexOf(k)==-1){
                esta=false;
                return;
              }
            });
            if(esta)
              ids.push(o._id);
          }else{
            esta=false;
            _.each(keys, function(k){
              if(n.indexOf(k)>=0){
                esta=true;
                return;
              }
            });
          }
          if(esta)
            ids.push(o._id);
  			}
  		});
      return ids;
    }, // end search
    getURL: function(){
      return process.env.ROOT_URL;
    }, // end getURL
    backup: function(uid) {
      var r=notas.find({user:uid},{sort:{timestamp:-1}});
      var bck=[]; 
      r.forEach(function(o){
        var elim=false;
        if(o.eliminado){
          elim=true;
        }
        bck.push({nota:o.nota,tags:o.tags,timestamp:o.timestamp, eliminado:elim});
      });

      var fs = Npm.require('fs');
      var archiver = Meteor.require('archiver');
      var archive = archiver('zip');

      archive.on('error', function(err) {
          console.log(err);
      });
      var ts=new Date();
      var carpeta=Npm.require('os').tmpDir()+"/";
      var fileName="Backup_BN_"+getFormatDate(ts)+".zip";
   
      var file=carpeta+uid+ts.getTime()+".zip"
      var output = fs.createWriteStream(file);
      archive.append(JSON.stringify(bck), { name: 'backup.json' });
      archive.pipe(output);
      archive.finalize(function(err, bytesWritten) {
        if (err) {
          console.log(err);
        } else {
          var buffer=fs.readFileSync(file,'binary');
          Fiber(function() { 
            backupsFS.storeBuffer(fileName, buffer, {
              owner: uid
            });
            fs.unlinkSync(file);
          }).run();
        }
      });
      
      return fileName;
    }, //end backup
    sendEmail: function(destinatarios, idNota, asunto) {
      var n=notas.findOne({_id:idNota});
      Email.send({
        from: "postmaster@blocdenotas.mailgun.org",
        to: destinatarios,
        replyTo: "postmaster@blocdenotas.mailgun.org" || undefined,
        subject: asunto,
        html: n.nota
      });
    } // end sendEmail
 });
});

function getFormatDate(ts_hms) {
  return ts_hms.toISOString().replace(/T/, ' ').replace(/\..+/, '');
}
