
Meteor.startup(function () {
  Meteor.methods({
    search: function (uid, key) {
    	var r=notas.find({user:uid},{sort:{timestamp:-1}});
      var ids=[];
      var keys=key.split(' ');
  		r.forEach(function(o){
  			var n=o.nota.replace(/(<\?[a-z]*(\s[^>]*)?\?(>|$)|<!\[[a-z]*\[|\]\]>|<!DOCTYPE[^>]*?(>|$)|<!--[\s\S]*?(-->|$)|<[a-z?!\/]([a-z0-9_:.])*(\s[^>]*)?(>|$))/gi, '');
  			n=n.replace(/&\w+?;/g,'');
        console.log(n);
        console.log(keys);
  			if(n && n.length>0) {
          var esta=false;
          _.each(keys, function(k){
            if(n.indexOf(k)>=0){
              esta=true;
              return;
            }
          });
          if(esta)
            ids.push(o._id);
          console.log(esta);
  			}
  		});
      return ids;
    }
  });
});
