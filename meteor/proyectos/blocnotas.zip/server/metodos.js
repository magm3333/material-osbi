
Meteor.startup(function () {
  Meteor.methods({
    search: function (uid, key, porAnd) {
    	var r=notas.find({user:uid},{sort:{timestamp:-1}});
      var ids=[];
      var keys=key.split(' ');
  		r.forEach(function(o){
  			var n=o.nota.replace(/(<\?[a-z]*(\s[^>]*)?\?(>|$)|<!\[[a-z]*\[|\]\]>|<!DOCTYPE[^>]*?(>|$)|<!--[\s\S]*?(-->|$)|<[a-z?!\/]([a-z0-9_:.])*(\s[^>]*)?(>|$))/gi, '');
  			n=n.replace(/&\w+?;/g,'');
  			if(n && n.length>0) {
          var esta=true;
          if(porAnd) {
            _.each(keys, function(k){
              if(n.indexOf(k)==-1){
                esta=false;
                return;
              }
            });
            if(esta)
              ids.push(o._id);
          }else{
            esta=false;
            _.each(keys, function(k){
              if(n.indexOf(k)>=0){
                esta=true;
                return;
              }
            });
          }
          if(esta)
            ids.push(o._id);
  			}
  		});
      return ids;
    },
    getURL: function(){
      return process.env.ROOT_URL;
    },
    backup: function(uid) {
      var r=notas.find({user:uid},{sort:{timestamp:-1}});
      var bck=[]; 
      r.forEach(function(o){
        var elim=false;
        if(o.eliminado){
          elim=true;
        }
        bck.push({nota:o.nota,tags:o.tags,timestamp:o.timestamp, eliminado:elim});
      });

      var sync = Npm.require('synchronize');

      var archiver = Npm.require('archiver');
      var archive = archiver('zip');
      sync(archive, 'finalize');

      var result="error";

      sync.fiber(function(){

        archive.on('error', function(err) {
            console.log(err);
        });

        var output = Npm.require('fs').createWriteStream('.meteor/example-output.zip');
        archive.append(JSON.stringify(bck), { name: 'backup.json' });
        archive.pipe(output);
        archive.finalize(function(err, written) {
          if (err) {
            console.log(err);
          }
          console.log(written + ' total bytes written');
          result= 'ok';
        });
      });

      console.log("end");
      return result;
    }
 });
});
