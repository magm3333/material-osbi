##jQuery UI - Meteor Smart Package

This is a simple port of [jqueryui](http://jqueryui.com/). This is jQuery 1.9.2, which matches the stable version of the [jquery ui bootstrap css theme](http://addyosmani.github.com/jquery-ui-bootstrap/).

###How to use?

1. Install [meteorite](https://github.com/oortcloud/meteorite)
2. `mrt add jquery-ui`

If you're looking for a theme that is bootstrap compatible to along with this Meteor package, check out the [jquery-ui-bootstrap meteor](https://github.com/TimHeckel/meteor-jquery-ui-bootstrap) smart package.
