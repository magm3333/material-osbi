# Meteor Bootstrap Package.

This is a drop-in replacement for meteor's core bootstrap package. It doesn't do anything special, just replaces core.

The idea is that this package should be updated more frequently than core.

## Usage Example

Have some files like these:

    meteor remove bootstrap
    mrt add bootstrap-updated

## Install

Install with meteorite: https://atmosphere.meteor.com/wtf/app