meteor-font-awesome
===================

Meteorite smart package for font awesome
[Font-Awesome](http://fortawesome.github.com/Font-Awesome/)

## How to install
1. `npm install -g meteorite` (if not already installed)
2. `mrt add font-awesome`
