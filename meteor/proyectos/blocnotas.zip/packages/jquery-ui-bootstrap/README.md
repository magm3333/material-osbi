##jQuery UI Bootstrap CSS Theme - Meteor Smart Package

This is [jquery-ui-bootstrap](http://addyosmani.github.com/jquery-ui-bootstrap/) bundled as a meteor smart package. (Note that this can be used along with the [jquery-ui meteor smart package](https://github.com/TimHeckel/meteor-jquery-ui) to use the jquery ui version that is compatible with this bootstrap theme. (Currently, 1.9.2)

###How to use?

1. Install [meteorite](https://github.com/oortcloud/meteorite)
2. `mrt install jquery-ui-bootstrap`
